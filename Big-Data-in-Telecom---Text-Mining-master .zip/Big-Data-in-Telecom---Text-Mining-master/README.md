# Big-Data-in-Telecom---Text-Mining
This project aims to address the social media review challenges for the telecom companies by extracting the tweets, analyzing them and segregating them into various categories to help the company understand the concerns of their customers and thereby, save millions and prevent customer churn.
